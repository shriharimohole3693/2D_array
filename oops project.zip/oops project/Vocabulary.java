import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Vocabulary extends JFrame implements ActionListener
{   

    String questions[][]=new String[20][5];
    String answers[][]=new String[20][2];
    String useranswers[][]=new String[20][1];
    JLabel qno,question;
    JRadioButton opt1,opt2,opt3,opt4;
    ButtonGroup groupoptions;
    public static int timer=30;
    public static int ans_given=0;
    public static int count=0;
    JButton next,lifeline,submit;
    public static int score=0;
    String name;
    Vocabulary(String name)
    {   
        this.name=name;
        setBounds(200,30,1000,750);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("image2.jpg"));
        JLabel image=new JLabel(i1);
        image.setBounds(0,0,1000,290);
        add(image);

        qno = new JLabel(); 
        qno.setBounds(80,350,50,27);
        qno.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(qno);
       

        question = new JLabel(); 
        question.setBounds(130,350,900,27);
        question.setFont(new Font("Tahoma",Font.PLAIN,19));
        add(question);

        setVisible(true);

	      questions[0][0] = "Choose the correct homophone for the sentence: 'I __ to the store to buy some apples '?";
        questions[0][1] = "reach";
        questions[0][2] = "go";
        questions[0][3] = "went";
        questions[0][4] = "gone";

        questions[1][0] = "Identify the verb tense in the following sentence: 'She will be singing at the concert.'";
        questions[1][1] = "present perfect";
        questions[1][2] = "future perfect";
        questions[1][3] = "future continuous";
        questions[1][4] = "simple future";

        questions[2][0] = "Identify the conjunction in the following sentence: 'I wanted to go, but it started raining.'";
        questions[2][1] = "But";
        questions[2][2] = "wanted";
        questions[2][3] = "to";
        questions[2][4] = "started";

        questions[3][0] = "What is the plural form of 'cactus'?";
        questions[3][1] = "cactuss";
        questions[3][2] = "cacti";
        questions[3][3] = "cactuses";
        questions[3][4] = "cacties";

        questions[4][0] = "Which of these words is an adverb ?";
        questions[4][1] = "under";
        questions[4][2] = "beautiful";
        questions[4][3] = "fast";
        questions[4][4] = "sleep";


        questions[5][0] = "What type of sentence is this: 'Close the door.'";
        questions[5][1] = "Declarative";
        questions[5][2] = "Exclamatory";
        questions[5][3] = "Interrogative";
        questions[5][4] = "Imperative";

        questions[6][0] = "Identify the gerund : sheela honestly likes to swim in this Swimming pool'";
        questions[6][1] = "to swim";
        questions[6][2] = "honestly";
        questions[6][3] = "swimming";
        questions[6][4] = "sheela";

        questions[7][0] = "Choose the correct sentence with proper subject-verb agreement:";
        questions[7][1] = "The dogs barks loudly.";
        questions[7][2] = "The dog barks loudly.";
        questions[7][3] = "The dog bark loudly.";
        questions[7][4] = "The dogs bark loudly.";

        questions[8][0] = "Which word is an indefinite article ?";
        questions[8][1] = "a";
        questions[8][2] = "an";
        questions[8][3] = "the";
        questions[8][4] = "is";

        questions[9][0] = "Which sentence is written in the passive voice ?";
        questions[9][1] = "The cat chased the mouse.";
        questions[9][2] = "The mouse runs quickly.";
        questions[9][3] = "The mouse was chased by the cat.";
        questions[9][4] = "She is reading a book.";

        questions[10][0] = "Which of the following is a demonstrative pronoun ?";
        questions[10][1] = "you";
        questions[10][2] = "ours";
        questions[10][3] = "them";
        questions[10][4] = "this";

        questions[11][0] = "Which of these sentences is written in the future perfect tense ?";
        questions[11][1] = "She is going to visit her grandmother tomorrow.";
        questions[11][2] = "We were studying for the test all night.";
        questions[11][3] = "He has finished his homework before dinner.";
        questions[11][4] = "They will have completed the project by next week.";

        questions[12][0] = "Choose the sentence with proper punctuation: ";
        questions[12][1] = "The sun is shining, the sky is blue.";
        questions[12][2] = "The sun is shining so the sky is blue.";
        questions[12][3] = "The sun is shining and the sky is blue.";
        questions[12][4] = "The sun is shining but the sky is blue.";

        questions[13][0] = "Identify the sentence that uses an adverb: ";
        questions[13][1] = "He ran quickly.";
        questions[13][2] = "She is a doctor.";
        questions[13][3] = "The car is blue.";
        questions[13][4] = "The cat is furry.";

        questions[14][0] = "Choose the synonym for 'temptataion' ";
        questions[14][1] = "A desire to do extraordinary things ";
        questions[14][2] = "A desire to do something bad or wrong";
        questions[14][3] = "A feeling of being better than the others";
        questions[14][4] = "The capacity of a person to deal with the things.";


        questions[15][0] = "Choose the synonym for 'meticulous':";
        questions[15][1] = "thorough";
        questions[15][2] = "Messy";
        questions[15][3] = "Careless";
        questions[15][4] = "Sloppy";

        questions[16][0] = "What is the antonym of 'vivid'?";
        questions[16][1] = "Lively";
        questions[16][2] = "Colorful";
        questions[16][3] = "Bright";
        questions[16][4] = "dull";

        questions[17][0] = "Which word does not belong to the group ?";
        questions[17][1] = "Deer";
        questions[17][2] = "Lion";
        questions[17][3] = "Ostrich";
        questions[17][4] = "Elephant";

        questions[18][0] = "complete sequence:'violet- Indigo - Blue -___- yellow - orange - Red' ? ";
        questions[18][1] = "Pink";
        questions[18][2] = "Brown";
        questions[18][3] = "Green";
        questions[18][4] = "Grey";

        questions[19][0] = "Which literary genre focuses on the emotions, thoughts, and internal experiences of characters ?";
        questions[19][1] = "Novel";
        questions[19][2] = "Dance";
        questions[19][3] = "Drama";
        questions[19][4] = "Comedy";

        answers[0][1] = "went";
        answers[1][1] = "future continuous";
        answers[2][1] = "But";
        answers[3][1] = "cacti";
        answers[4][1] = "fast";
        answers[5][1] = "Imperative";
        answers[6][1] = "swimming";
        answers[7][1] = "The dog barks loudly.";
        answers[8][1] = "a";
        answers[9][1] = "The mouse was chased by the cat.";
        answers[10][1] = "this";
        answers[11][1] = "They will have completed the project by next week.";
        answers[12][1] = "The sun is shining and the sky is blue.";
        answers[13][1] = "He ran quickly.";
        answers[14][1] = "A desire to do something bad or wrong";
        answers[15][1] = "thorough";
        answers[16][1] = "dull";
        answers[17][1] = "Ostrich";
        answers[18][1] = "Green";
        answers[19][1] = "Drama";

        opt1= new JRadioButton();
        opt1.setBounds(120,410,700,30);
        opt1.setBackground(Color.WHITE);
        opt1.setFont(new Font("Dialog",Font.PLAIN,18));
        add(opt1);

        opt2= new JRadioButton();
        opt2.setBounds(120,460,700,30);
        opt2.setBackground(Color.WHITE);
        opt2.setFont(new Font("Dialog",Font.PLAIN,18));
        add(opt2);

        opt3= new JRadioButton();
        opt3.setBounds(120,510,700,30);
        opt3.setBackground(Color.WHITE);
        opt3.setFont(new Font("Dialog",Font.PLAIN,18));
        add(opt3);

        opt4= new JRadioButton();
        opt4.setBounds(120,560,700,30);
        opt4.setBackground(Color.WHITE);
        opt4.setFont(new Font("Dialog",Font.PLAIN,18));
        add(opt4);

         groupoptions=new ButtonGroup();
         groupoptions.add(opt1);
         groupoptions.add(opt2);
         groupoptions.add(opt3);
         groupoptions.add(opt4);
        


        lifeline=new JButton("50-50 Lifeline");
        lifeline.setBounds(120,640,180,30);
        lifeline.setFont(new Font("Tahoma",Font.PLAIN,18));
        lifeline.setBackground(new Color(30,144,255));
        lifeline.setForeground(Color.WHITE);
        lifeline.addActionListener(this);
        add(lifeline);

        next=new JButton("Next");
        next.setBounds(360,640,180,30);
        next.setFont(new Font("Tahoma",Font.PLAIN,18));
        next.setBackground(new Color(30,144,255));
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        add(next);

        submit=new JButton("Submit");
        submit.setBounds(600,640,180,30);
        submit.setFont(new Font("Tahoma",Font.PLAIN,18));
        submit.setBackground(new Color(30,144,255));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        submit.setEnabled(false);
        add(submit);


        start(count);
       
        

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
      if(ae.getSource()==next)
      {
        repaint();
        opt1.setEnabled(true);
        opt2.setEnabled(true);
        opt3.setEnabled(true);
        opt4.setEnabled(true);
        
        ans_given=1;
        if(groupoptions.getSelection()==null)
      {
         useranswers[count][0]="";
      }else
      {
        useranswers[count][0]=groupoptions.getSelection().getActionCommand();
      }

      if(count==18)
      {
        next.setEnabled(false);
        submit.setEnabled(true);
      }

        count++;
        start(count);
      }
      else if(ae.getSource()==lifeline)
      {
        if(count==2||count==8||count==13||count==15)
        {
            opt2.setEnabled(false);
            opt4.setEnabled(false);
        }
        else if(count==3||count==7)
        {
             opt1.setEnabled(false);
             opt3.setEnabled(false);
        }
        else if(count==0||count==1||count==4||count==6||count==9||count==12||count==14||count==17||count==18||count==19)
        {
             opt1.setEnabled(false);
             opt2.setEnabled(false);
        }
        else{
            opt2.setEnabled(false);
            opt3.setEnabled(false);
        }
        lifeline.setEnabled(false);
      }
      else if(ae.getSource()==submit){
        ans_given=1;
      if(groupoptions.getSelection()==null)
      {
         useranswers[count][0]="";
      }else
      {
        useranswers[count][0]=groupoptions.getSelection().getActionCommand();
      }
      for(int i=0;i<useranswers.length;i++)
      {
        if(useranswers[i][0].equals(answers[i][1]))
        {
            score+=5;
        }
        else{
            score+=0;
        }
      }
      setVisible(false);
      new score(name,score,"Vocabulary");
   
      }
    }

   
   public void paint(Graphics g)
   {
    super.paint(g);

    String time="Time left :" + timer + " seconds";
    g.setColor(Color.RED);
    g.setFont(new Font("Tahoma",Font.BOLD,28));

    if(timer>0)
    {
        g.drawString(time,600,550);
    }
    else
    {
        g.drawString("Times up!!!",600,550);
    }
    timer--;
      try {
    Thread.sleep(1000);
    repaint();
    
   } catch (Exception e) {
    e.printStackTrace();
   }

   if(ans_given==1)
   {
    ans_given=0;
    timer=30;
   }
   else if(timer<0)
   {
      timer=30;

      opt1.setEnabled(true);
      opt2.setEnabled(true);
      opt3.setEnabled(true);
      opt4.setEnabled(true);
      
      if(count==18)
      {
        next.setEnabled(false);
        submit.setEnabled(true);
      }

       if(count==19)
      {
       if(groupoptions.getSelection()==null)
      {
         useranswers[count][0]="";
      }else
      {
        useranswers[count][0]=groupoptions.getSelection().getActionCommand();
      }
     
      for(int i=0;i<useranswers.length;i++)
      {
        if(useranswers[i][0].equals(answers[i][1]))
        {
            score+=5;
        }else
        {
            score+=0;
        }
      }
      setVisible(false);
      new score(name, score, "Vocabulary");
      }
       else{

      if(groupoptions.getSelection()==null)
      {
         useranswers[count][0]="";
      }else
      {
        useranswers[count][0]=groupoptions.getSelection().getActionCommand();
      }
      count++;
      start(count);}
   }
}
  


    public void start(int count)
    {
        qno.setText(""+ (count + 1) + ". ");
        question.setText(questions[count][0]);
        opt1.setText(questions[count][1]);
        opt1.setActionCommand(questions[count][1]);

        opt2.setText(questions[count][2]);
        opt2.setActionCommand(questions[count][2]);

        opt3.setText(questions[count][3]);
        opt3.setActionCommand(questions[count][3]);

        opt4.setText(questions[count][4]);
        opt4.setActionCommand(questions[count][4]);

        groupoptions.clearSelection();
       
    }
    public static void main(String[] args) {
        new Vocabulary("user");
    }
}