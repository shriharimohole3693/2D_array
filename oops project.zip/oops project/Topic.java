import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Topic extends JFrame implements ActionListener {

    JButton GK,Back,Aptitude,Vocabulary, Programming;
    String name;
    Topic(String name)
  {  
     this.name=name;
     getContentPane().setBackground(Color.WHITE);
     setLayout(null);

     ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("original.jpg"));
     JLabel image=new JLabel(i1);
     image.setBounds(0,-250,500,900);
     add(image);

      JLabel heading=new JLabel("Choose Your Topic  ");
      heading.setBounds(555,0,450,80);
      heading.setFont(new Font("Tahoma",Font.BOLD,41));
      heading.setForeground(new Color(204, 50, 53));
      add(heading);

      GK=new JButton("GK");
      GK.setBounds(650,90,200,30);
      GK.setFont(new Font("Times New Roman",Font.PLAIN,28));
      GK.setBackground(new Color(30,144,255));
      GK.setForeground(Color.WHITE);
      GK.addActionListener(this);
      add(GK);

       Aptitude=new JButton("Aptitude");
       Aptitude.setBounds(650,150,200,30);
       Aptitude.setFont(new Font("Times New Roman",Font.PLAIN,28));
       Aptitude.setBackground(new Color(30,144,255));
       Aptitude.setForeground(Color.WHITE);
       Aptitude.addActionListener(this);
       add( Aptitude);

       Programming=new JButton("Programming");
       Programming.setBounds(650,210,200,30);
       Programming.setFont(new Font("Times New Roman",Font.PLAIN,28));
       Programming.setBackground(new Color(30,144,255));
       Programming.setForeground(Color.WHITE);
       Programming.addActionListener(this);
       add( Programming);

       Vocabulary=new JButton("Vocabulary");
       Vocabulary.setBounds(650,270,200,30);
       Vocabulary.setFont(new Font("Times New Roman",Font.PLAIN,28));
       Vocabulary.setBackground(new Color(30,144,255));
       Vocabulary.setForeground(Color.WHITE);
       Vocabulary.addActionListener(this);
       add( Vocabulary);

       Back=new JButton("Back");
       Back.setBounds(650,330,200,30);
       Back.setFont(new Font("Times New Roman",Font.PLAIN,28));
       Back.setBackground(new Color(120,44,155));
       Back.setForeground(Color.WHITE);
       Back.addActionListener(this);
       add(Back);

       setSize(1000, 435);
       setLocation(240,200);
       setVisible(true);
}
public void  actionPerformed(ActionEvent ae)
  {
    if(ae.getSource()==GK)
    { 
      setVisible(false);
      new rules(name);
  
    }
   else if(ae.getSource()==Aptitude)
  {
   setVisible(false);
   new rulesapti(name);
  }
  else if(ae.getSource()==Vocabulary)
  {
   setVisible(false);
   new rulesvoc(name);
  }
  else if(ae.getSource()==Programming)
  {
   setVisible(false);
   new rulesprog(name);
  }
   else if(ae.getSource()==Back)
  {
   setVisible(false);
   new login();
  }

  

  }
  public static void main(String[] args)
  {
    new Topic("user");
  }
}

