import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class score extends JFrame implements ActionListener  {
    

    

    score(String name,int score,String className){
        setBounds(330,150,800,550);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("image 3.png"));
        Image i2=i1.getImage().getScaledInstance(300,250,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);

        JLabel image=new JLabel(i3);
        image.setBounds(0,150,290,350);
        add(image);

        JLabel heading = new JLabel("Thank-you "+ name + " for playing Quiz-connect"); 
        heading.setBounds(60,40,800,40);
        heading.setFont(new Font("Tahoma",Font.BOLD,26));
        add(heading);


        JLabel lblscore = new JLabel("Your Score is  :  " + score +" /100"); 
        lblscore.setBounds(340,160,700,40);
        lblscore.setFont(new Font("Tahoma",Font.BOLD,29));
        add(lblscore);

        String performance;
        if (score >= 90 && score <= 100) {
           performance = "Excellent";
        } else if (score >= 75 && score < 90) {
           performance = "Very Good";
        } else if (score >= 60 && score < 75) {
           performance = "Good";
      } else if (score >= 50 && score < 60) {
           performance = "Average";
      } else if (score >= 35 && score < 50) {
           performance = "Satisfactory";
      } else {
           performance = "Poor";
      }
        JLabel lblPerformance = new JLabel("Performance  :  " + performance);
        lblPerformance.setBounds(345, 240, 700, 40);
        lblPerformance.setFont(new Font("Tahoma", Font.BOLD, 29));
        add(lblPerformance);

        JLabel lblClassName = new JLabel("Topic  :  " + className); 
        lblClassName.setBounds(345, 320, 700, 40);
        lblClassName.setFont(new Font("Tahoma", Font.BOLD, 29));
        add(lblClassName);


        JButton submit=new JButton("Play Again");
        submit.setBounds(560,440,160,35);
        submit.setFont(new Font("Times New Roman",Font.PLAIN,28));
        submit.setBackground(new Color(30,144,255));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        add(submit);

        


        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae)
    {  

       
       setVisible(false);
       new login();
    }
    public static void main(String[] args) {
        new score("user",0,"class");
    }
}